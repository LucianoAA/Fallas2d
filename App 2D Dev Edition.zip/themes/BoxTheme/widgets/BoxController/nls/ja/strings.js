define({
  "_widgetLabel": "ボックス コントローラー"
});