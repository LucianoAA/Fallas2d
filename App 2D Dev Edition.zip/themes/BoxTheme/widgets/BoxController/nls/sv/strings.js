define({
  "_widgetLabel": "Ruthanteraren"
});