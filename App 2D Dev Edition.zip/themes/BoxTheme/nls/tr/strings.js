define({
  "_themeLabel": "Kutu Teması",
  "_layout_default": "Varsayılan düzen",
  "_layout_top": "Üst düzen"
});