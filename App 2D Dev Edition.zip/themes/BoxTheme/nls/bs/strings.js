define({
  "_themeLabel": "Tema okvira",
  "_layout_default": "Zadani izgled",
  "_layout_top": "Glavni izgled"
});