define({
  "_themeLabel": "ערכת נושא תיבה",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_top": "פריסה עליונה"
});